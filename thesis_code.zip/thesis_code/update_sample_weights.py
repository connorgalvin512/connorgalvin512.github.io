import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from statistics import mean
import random
import math
from scipy.stats import beta
from scipy.integrate import quad
from statistics import stdev, pstdev
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pylab as plt
from sklearn.metrics import confusion_matrix
from sklearn import metrics
import seaborn as sns
from scipy.stats import hmean
from sklearn.metrics import mean_squared_error
from scipy import spatial
from scipy.io import arff
from sklearn.model_selection import train_test_split
from pyod.models.knn import KNN

data = arff.loadarff("C:/Users/conno/Documents/Cardiotocography_norm.arff") #this works if you have the file into the main directory
df = pd.DataFrame(data[0])
df['outlier'] = [string.decode("utf-8") for string in df['outlier'].values]
df['outlier'] = [1 if string == 'yes' else 0 for string in df['outlier'].values]
y = df['outlier'].values #these are the labels (1 -> anomaly, 0 -> normal)
numerical_col = df.columns[:23] #the columns containing numerical features (21 in total)
X_total = df[numerical_col].values #training set without the class label
X_train, X_test, = train_test_split(X_total, test_size = 1/4)
X_train, X_valid = train_test_split(X_train, test_size = 1/3)

X_test_labels = X_test[:, -1]
X_train_labels = X_train[:, -1]
X_valid_labels = X_valid[:, -1]

#Remove labels and IDs for datasets
X_test = X_test[:, :21]
X_valid = X_valid[:, :21]
X_train = X_train[:, :21]



def stability(concat_pos, contamination, data):
    list_of_point_pos = []

    for j in range(0, len(data)):
        current_point_list = []
        for i in concat_pos:
            current_point_list.append((i.index(j) + 1) / len(data))
        list_of_point_pos.append(current_point_list)

    mode = 1 - contamination
    var = (mode * (1 - mode)) * 0.1
    alpha_param = ((((1 - mode) / var) - (1 / mode)) * mode ** 2) + 1
    beta_param = ((alpha_param - 1) * ((1 / mode) - 1)) + 1

    x = np.linspace(beta.ppf(0.00, alpha_param, beta_param),
                    beta.ppf(1.00, alpha_param, beta_param), len(data))

    def f(x):
        return beta.pdf(x, alpha_param, beta_param)

    point_list = []
    area_list = []
    std_list = []

    for index, pt in enumerate(list_of_point_pos):
        min1 = min(pt)
        max1 = max(pt)
        stdev = pstdev(pt)
        std_list.append(stdev)
        area_under_beta = quad(lambda x: f(x), min1, max1)
        area_under_beta = area_under_beta[0]
        point_list.append(pt)
        area_list.append(area_under_beta)

    point_df = pd.DataFrame(point_list)
    AUB_df = pd.DataFrame(area_list)
    stdev_df = pd.DataFrame(std_list)

    point_df.insert(0, "AUB", AUB_df)
    point_df.insert(0, "STDEV", stdev_df)

    random_stdev = np.std(np.random.rand(10000))
    point_df["Score"] = point_df["AUB"] * point_df["STDEV"] * (1 / random_stdev)

    average_score = round(point_df["Score"].mean(), 3)
    average_score = 1 - average_score

    return average_score


def stability_learn(name, X_total, labels,
                    Model, numNeighbors,  subsetlow, subsethigh,
                    NumberofComparisons, NumberofUpdates, NumberofRuns):


    contamination = sum(labels) / len(labels)

    X_train, X_test, trainlabels, testlabels = train_test_split(X_total, labels, test_size = 1/4)
    X_train, X_valid, trainlabels, validlabels = train_test_split(X_train, trainlabels, test_size=1 / 3)

    norm_list = []

    if Model == 'KNN' or Model == "UKN":
        pass
    else:
        testlabels = [1 if el == 0 else -1 for el in testlabels]
        validlabels = [1 if el == 0 else -1 for el in validlabels]

    for run in range(NumberofRuns):
        internorm_list = []
        plot_list_AUC_test = []
        plot_list_stability_test = []
        plot_list_AUC_valid = []
        plot_list_stability_valid = []
        plot_list_combined_valid = []

        normal_contrib_list = []
        raw = [float(1 / len(X_train))] * len(X_train)

        count = 0
        for update in range(NumberofUpdates):
            print(count)

            if count < 2:
                #initialization with two runs
                pass

            else:
                #sampleweight updates
                stability_ratio = plot_list_stability_valid[-1] / plot_list_stability_valid[-2]
                for index, d2 in enumerate(normal_contrib_list[-1]):
                    d2 = d2 * len(X_train)
                    d1 = normal_contrib_list[-2][index] * len(X_train)
                    if d2 > 0 and d1 > 0:
                        alpha = (d2 - d1)
                        if stability_ratio > 1:
                            raw[index] = raw[index] * math.exp(alpha)
                        else:
                            raw[index] = raw[index] * math.exp(-1 * alpha)
                    else:
                        pass

            norm = [(float(i) / sum(raw)) for i in raw]
            norm_array = np.asarray(norm)
            norm_new = [x * len(X_train) for x in norm]
            internorm_list.append(norm_new)

            concat_pos_valid = []
            concat_pos_test = []
            contrib_list = [[] for i in range(len(X_train))]


            for i in range(NumberofComparisons):
                subsample_size = random.randint(int(len(X_train) *subsetlow), int(len(X_train) * subsethigh))
                sample_indices = np.random.choice(np.arange(len(X_train)), size=subsample_size, p=norm, replace=False)
                sub_X_train = X_train[sample_indices]

                for index, element in enumerate(X_train):
                    if (sub_X_train == element).all(1).any():
                        contrib_list[index].append(1 / subsample_size)

                if Model == 'UKN':
                    # weighted KNNO
                    clf = KNN(n_neighbors=numNeighbors, contamination=contamination, method='mean')
                    clf.fit(sub_X_train)

                    valid_scores = []
                    for point in X_valid:
                        distances, index = spatial.KDTree(sub_X_train).query(point, k=numNeighbors)
                        sample_weights = norm_array[index]
                        sum_l = sum(sample_weights)
                        sample_weights = [math.exp(g / sum_l) for g in sample_weights]
                        score = sum(sample_weights[g] * distances[g] for g in range(len(distances))) / sum(sample_weights)
                        valid_scores.append(score)

                    test_scores = []
                    for point in X_test:
                        distances, index = spatial.KDTree(sub_X_train).query(point, k=numNeighbors)
                        sample_weights = norm_array[index]
                        sum_l = sum(sample_weights)
                        sample_weights = [math.exp(g / sum_l) for g in sample_weights]
                        score = sum(sample_weights[g] * distances[g] for g in range(len(distances))) / sum(sample_weights)
                        test_scores.append(score)

                    pred_valid_labels = clf.predict(X_valid)
                    pred_test_labels = clf.predict(X_test)


                elif Model == 'KNN':
                    # train kNN detector
                    clf = KNN(n_neighbors=numNeighbors, contamination=contamination, method='mean')
                    clf.fit(sub_X_train)
                    pred_valid_labels = clf.predict(X_valid)
                    valid_scores = clf.decision_function(X_valid)
                    pred_test_labels = clf.predict(X_test)
                    test_scores = clf.decision_function(X_test)

                elif Model == 'IF':
                    i_forest = IsolationForest(contamination=contamination, behaviour='new')
                    i_forest.fit(sub_X_train)
                    pred_valid_labels = i_forest.predict(X_valid)
                    valid_scores = i_forest.decision_function(X_valid)
                    pred_test_labels = i_forest.predict(X_test)
                    test_scores = i_forest.decision_function(X_test)

                elif Model == 'LOF':
                    clf = LocalOutlierFactor(n_neighbors=numNeighbors, contamination=contamination, novelty=True)
                    clf.fit(sub_X_train)
                    pred_valid_labels = clf.predict(X_valid)
                    valid_scores = clf.decision_function(X_valid)
                    pred_test_labels = clf.predict(X_test)
                    test_scores = clf.decision_function(X_test)

                average_AUC_valid = metrics.roc_auc_score(validlabels, pred_valid_labels)
                average_AUC_test = metrics.roc_auc_score(testlabels, pred_test_labels)

                valid_score_position = []
                for index, value in enumerate(valid_scores):
                    valid_score_position.append([value, index])

                test_score_position = []
                for index, value in enumerate(test_scores):
                    test_score_position.append([value, index])

                if Model == 'KNN' or Model=='UKN':
                    valid_score_position.sort()
                    test_score_position.sort()
                else:
                    valid_score_position.sort(reverse=True)
                    test_score_position.sort(reverse=True)
                valid_sort_pos = [el[1] for el in valid_score_position]
                concat_pos_valid.append(valid_sort_pos)
                test_sort_pos = [el[1] for el in test_score_position]
                concat_pos_test.append(test_sort_pos)

            #Calculating contributions
            normal_factor = 0
            normal_contrib_sublist = []
            for sub_list in contrib_list:
                normal_factor += sum(sub_list)
            for sub_list in contrib_list:
                normal_contrib_sublist.append(sum(sub_list) / normal_factor)
            normal_contrib_list.append(normal_contrib_sublist)

            average_score_valid = stability(concat_pos_valid, contamination, X_valid)
            average_score_test = stability(concat_pos_test, contamination, X_test)


            plot_list_AUC_valid.append(average_AUC_valid)
            plot_list_stability_valid.append(average_score_valid)
            print([average_AUC_valid, average_score_valid])

            plot_list_AUC_test.append(average_AUC_test)
            plot_list_stability_test.append(average_score_test)
            print([average_AUC_test, average_score_test])

            count += 1

        #Stability and AUC plots
        plt.figure()
        plt.plot(plot_list_AUC_test, color='blue', label='AUC of ROC Curve')
        label = "{:.3f}".format(plot_list_AUC_test[0])
        plt.annotate(label,  # this is the text
                     (0,plot_list_AUC_test[0]),  # this is the point to label
                         textcoords="offset points",  # how to position the text
                         xytext=(0, 10),  # distance from text to points (x,y)
                         ha='center')
        label = "{:.3f}".format(plot_list_AUC_test[-1])
        plt.annotate(label,  # this is the text
                     (len(plot_list_AUC_test)-1,plot_list_AUC_test[-1]),  # this is the point to label
                         textcoords="offset points",  # how to position the text
                         xytext=(0, 10),  # distance from text to points (x,y)
                         ha='center')
        plt.plot(plot_list_stability_test, color='red', label='Stability Score')
        label = "{:.3f}".format(plot_list_stability_test[0])
        plt.annotate(label,  # this is the text
                     (0,plot_list_stability_test[0]),  # this is the point to label
                         textcoords="offset points",  # how to position the text
                         xytext=(0, -10),  # distance from text to points (x,y)
                         ha='center')
        label = "{:.3f}".format(plot_list_stability_test[-1])
        plt.annotate(label,  # this is the text
                     (len(plot_list_stability_test)-1,plot_list_stability_test[-1]),  # this is the point to label
                         textcoords="offset points",  # how to position the text
                         xytext=(0, -10),  # distance from text to points (x,y)
                         ha='center')
        plt.title('Effect of sample weight updates on average Stability and AUC scores')
        plt.xlabel('Number of sample weight updates')
        plt.legend()
        #plt.savefig("C:/Users/conno/PycharmProjects/thesis/figures_ranged/"+str(name)+str(run)+str(Model)+".png")
        plt.show()

        norm_list.append(internorm_list)

    # Colormap plot
    newnorm2 = []
    for y in norm_list:
        newnorm2.append(y[-1])
    new_norm_list =[]
    for y in newnorm2:
        part_new_norm = [0 if el < 1 else el for el in y]
        part_new_norm = [1 if el > 1 else el for el in part_new_norm]
        new_norm_list.append(part_new_norm)
    c_map_list = [sum(l) for l in zip(*new_norm_list)]
    plt.figure()
    cmap = sns.diverging_palette(220, 20, as_cmap=True)
    f, ax = plt.subplots()
    points = ax.scatter(X_train[:,0], X_train[:,1], c=c_map_list, s=50, cmap=cmap)
    f.colorbar(points)
    plt.title('Points with high weight after 25 s.w updates')
    #plt.savefig("C:/Users/conno/PycharmProjects/thesis/figures_ranged/" + str(name)+ str(Model) + "Colormap.png")
    plt.show()

    #MSE plots
    base_norm = norm_list[0]
    norm1 = norm_list[1]
    norm2 = norm_list[2]
    norm3 = norm_list[3]
    norm4 = norm_list[4]
    norm5 = norm_list[5]

    def nearest_mse(norm, k_num):
        big_new_mse = []
        for w in range(NumberofUpdates):
            new_mse = []
            for i in range(len(X_train)):
                pt = X_train[i]
                distance, index = spatial.KDTree(X_test).query(pt, k=k_num)
                part_list = np.array(norm[w])
                part_list = part_list[index]
                aver = sum(part_list)/len(part_list)
                new_mse.append(aver)
            big_new_mse.append(new_mse)
        return big_new_mse

    base_norm = nearest_mse(base_norm, numNeighbors)
    norm1 = nearest_mse(norm1, numNeighbors)
    norm2 = nearest_mse(norm2, numNeighbors)
    norm3 = nearest_mse(norm3, numNeighbors)
    norm4 = nearest_mse(norm4, numNeighbors)
    norm5 = nearest_mse(norm5, numNeighbors)

    mse_list = []

    for w in range(NumberofUpdates):
        mse1 = mean_squared_error(base_norm[w], norm1[w])
        mse2 = mean_squared_error(base_norm[w], norm2[w])
        mse3 = mean_squared_error(base_norm[w], norm3[w])
        mse4 = mean_squared_error(base_norm[w], norm4[w])
        mse5 = mean_squared_error(base_norm[w], norm5[w])
        mse_list.append([mse1, mse2, mse3, mse4, mse5])

    mse1_list  =  [item[0] for item in mse_list]
    mse2_list  =  [item[1] for item in mse_list]
    mse3_list  =  [item[2] for item in mse_list]
    mse4_list  =  [item[3] for item in mse_list]
    mse5_list  =  [item[4] for item in mse_list]

    plt.figure()
    plt.plot(mse1_list, color='blue', label='1')
    plt.plot(mse2_list, color='green', label='2')
    plt.plot(mse3_list, color='red', label='3')
    plt.plot(mse4_list, color='orange', label='4')
    plt.plot(mse5_list, color='black', label='5')
    plt.title('MSE of sample weights for different runs')
    plt.xlabel('Number of sample weight updates')
    plt.ylabel('Mean Square Error')
    plt.legend()
    #plt.savefig("C:/Users/conno/PycharmProjects/thesis/figures_ranged/" + str(name) + str(Model) + "MsePlot.png")
    plt.show()

def compute_experiments(args):
    #It's useful just for notation
    return stability_learn(*args)


stability_learn("cardiography", X_total, y,
                    'KNN', 20, 0.5, 0.5,
                    50, 25, 6)