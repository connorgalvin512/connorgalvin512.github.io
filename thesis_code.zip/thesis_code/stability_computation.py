import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from statistics import mean
import random
import math
from scipy.stats import beta
from scipy.integrate import quad
from statistics import stdev, pstdev
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pylab as plt
from sklearn.metrics import confusion_matrix
from sklearn import metrics
import seaborn as sns
from scipy.stats import hmean
from sklearn.metrics import mean_squared_error
from scipy import spatial
from scipy.io import arff
from sklearn.model_selection import train_test_split
from pyod.models.knn import KNN

#Loading and processing cardiotocography dataset

data = arff.loadarff("C:/Users/conno/Documents/Cardiotocography_norm.arff") #this works if you have the file into the main directory
df = pd.DataFrame(data[0])
df['outlier'] = [string.decode("utf-8") for string in df['outlier'].values]
df['outlier'] = [1 if string == 'yes' else 0 for string in df['outlier'].values]
y = df['outlier'].values #these are the labels (1 -> anomaly, 0 -> normal)
numerical_col = df.columns[:23] #the columns containing numerical features (21 in total)
X_total = df[numerical_col].values #training set without the class label
X_train, X_test, = train_test_split(X_total, test_size = 1/4)
X_train, X_valid = train_test_split(X_train, test_size = 1/3)
X_test_labels = X_test[:, -1]
X_train_labels = X_train[:, -1]
X_valid_labels = X_valid[:, -1]


#Remove labels and IDs for datasets
X_test = X_test[:, :21]
X_valid = X_valid[:, :21]
X_train = X_train[:, :21]


def stability(name, data, labels,
                     Model, numNeighbors, subsetlow, subsethigh,
                    NumberofComparisons):

    contamination = sum(labels)/len(labels)
    X_train, X_test, trainlabels, testlabels = train_test_split(data, labels, test_size = 1/3)

    #Coverting to consistent labels
    if Model == 'KNN':
        pass
    else:
        testlabels = [1 if el == 0 else -1 for el in testlabels]

    #Uniform sample weights
    raw = [float(1 / len(X_train))] * len(X_train)
    norm = [(float(i) / sum(raw)) for i in raw]

    concat_pos_test = []
    for i in range(NumberofComparisons):
        subsample_size = random.randint(int(len(X_train) *subsetlow), int(len(X_train) * subsethigh))
        sample_indices = np.random.choice(np.arange(len(X_train)), size=subsample_size, p=norm, replace=False)
        sub_X_train = X_train[sample_indices]

        if Model == 'KNN':
            # train kNN detector
            clf = KNN(n_neighbors=numNeighbors, contamination=contamination, method='mean')
            clf.fit(sub_X_train)
            pred_test_labels = clf.predict(X_test)
            test_scores = clf.decision_function(X_test)

        elif Model == 'IF':
            i_forest = IsolationForest(contamination=contamination, behaviour='new')
            i_forest.fit(sub_X_train)
            pred_test_labels = i_forest.predict(X_test)
            test_scores = i_forest.decision_function(X_test)

        elif Model == 'LOF':
            clf = LocalOutlierFactor(n_neighbors=numNeighbors, contamination=contamination, novelty=True)
            clf.fit(sub_X_train)
            pred_test_labels = clf.predict(X_test)
            test_scores = clf.decision_function(X_test)

        auc = metrics.roc_auc_score(testlabels, pred_test_labels)

        test_score_position = []
        for index, value in enumerate(test_scores):
            test_score_position.append([value, index])

        if Model == 'KNN':
            test_score_position.sort()
        else:
            test_score_position.sort(reverse=True)

        test_sort_pos = [el[1] for el in test_score_position]
        concat_pos_test.append(test_sort_pos)

    list_of_point_pos = []
    # list_of_point_pos is the ri(xj) in the paper)
    for j in range(0, len(X_test)):
        current_point_list = []
        for i in concat_pos_test:
            current_point_list.append((i.index(j) + 1) / len(X_test))
        list_of_point_pos.append(current_point_list)

    mode = 1 - contamination
    var = (mode * (1 - mode)) * 0.1
    alpha_param = ((((1 - mode) / var) - (1 / mode)) * mode ** 2) + 1
    beta_param = ((alpha_param - 1) * ((1 / mode) - 1)) + 1


    def f(x):
        return beta.pdf(x, alpha_param, beta_param)

    point_list = []
    area_list = []
    std_list = []

    for index, pt in enumerate(list_of_point_pos):
        min1 = min(pt)
        max1 = max(pt)
        stdev = pstdev(pt)
        std_list.append(stdev)
        area_under_beta = quad(lambda x: f(x), min1, max1)
        area_under_beta = area_under_beta[0]
        point_list.append(pt)
        area_list.append(area_under_beta)

    point_df = pd.DataFrame(point_list)
    AUB_df = pd.DataFrame(area_list)
    stdev_df = pd.DataFrame(std_list)

    point_df.insert(0, "AUB", AUB_df)
    point_df.insert(0, "STDEV", stdev_df)

    random_stdev = np.std(np.random.rand(len(X_test)))
    point_df["Score"] = point_df["AUB"] * point_df["STDEV"] * (1 / random_stdev)

    average_score = round(point_df["Score"].mean(), 3)
    average_score = 1 - average_score

    npa = np.asarray(point_list, dtype=np.float32)
    npat = np.transpose(npa)
    ax = sns.heatmap(npat, cmap="YlGnBu", xticklabels=50, yticklabels=10)
    ax.set(xlabel='Points', ylabel='Iterations')
    ax.invert_yaxis()
    plt.title("Stability Score: " + str(round(average_score, 2)))
    plt.show()
    print(name, contamination, average_score, auc)

def compute_experiments(args):
    #It's useful just for notation
    return stability(*args)


stability("cradiography",X_total, y,
                    'LOF', 40, 0.5, 0.5,
                    100)
