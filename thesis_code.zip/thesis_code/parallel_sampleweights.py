import workers
import numpy as np
import matplotlib.pyplot as plt
import sklearn.svm as svm
import sklearn.metrics as metrics
import pandas as pd
import random
import math
import scipy.special
from multiprocessing import get_context, set_start_method
from multiprocessing import Pool, freeze_support, cpu_count
import os #we need it to remove files
import mmap
from pyod.models.knn import KNN
from pyod.models.lof import LOF
from pyod.models.iforest import IForest
from sklearn.metrics import confusion_matrix
from scipy.special import erf
from scipy.io import arff
import itertools
from sklearn.model_selection import StratifiedKFold
import update_sample_weights

#Parrallel Processing script to run UpdateSampleWeights for multiple datasets at the same time


def ignore_warnings():
    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)
    warnings.simplefilter(action='ignore', category=Warning)

ignore_warnings()
np.random.seed(331)

names = ['Shuttle_withoutdupl_norm_v02', 'Glass_withoutdupl_norm',\
         'Stamps_withoutdupl_norm_09', 'WDBC_withoutdupl_norm_v02','Ionosphere_withoutdupl_norm',\
         'Lymphography_withoutdupl_norm_1ofn', 'WBC_norm_v02']
n_num_columns = [9,7,9,30,32,19,9]


def run_experiments(names, n_num_columns):
    tot_dataset = len(names)
    Dtrain_list = []
    y_list = []
    df_list = []
    name_list = ["" for x in range(tot_dataset)]
    model = 'IF'
    for i in range(tot_dataset):
        print('aaaa')
        datasetname = names[i]
        n_num_col = n_num_columns[i]
        name_list[i] = datasetname.split('_')[0]
        # data = arff.loadarff('../datasets/'+datasetname+'.arff') #change directory!
        data = arff.loadarff('C:/Users/conno/PycharmProjects/thesis/datasets/' + datasetname + '.arff')
        df = pd.DataFrame(data[0])
        df['outlier'] = [string.decode("utf-8") for string in df['outlier'].values]
        df_list.append(df)
        y_list.append(np.asarray([1 if string == 'yes' else 0 for string in df['outlier'].values]))
        Dtrain_list.append(df[df.columns[:n_num_col]].values)  # entire data set

    all_args = [(name_list[i], Dtrain_list[i], y_list[i], 0.1, 'IF', 10, 0.25, 0.75,
                    50, 25, 6) for i in range(tot_dataset)]
    #all_args =
    print('ddd')
    blah = cpu_count()
    print(blah)
    if __name__ == '__main__':
        num_processors = 7
        p = Pool(processes=num_processors)
        output = p.map(update_sample_weights.compute_experiments, all_args)
        print(output)

run_experiments(names,n_num_columns)